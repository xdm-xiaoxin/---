#!/bin/bash
#
# 学习通助手 · 懒人一键配置（macOS）
# ------------------------------------------------------------------
# 这个脚本会把「配置文件夹」里的 tampermonkey_stable.crx 解包并装进一个
# 专用浏览器配置里，然后打开油猴的安装页面，让你点一下就装好 xxt 脚本。
#
# 用法：
#   双击本文件即可（推荐）；或在终端里：
#     ./一键配置.command                # 一键配置并启动
#     ./一键配置.command --dry-run      # 只检查环境，不启动浏览器
#     ./一键配置.command --main-profile # 装进你平时的浏览器配置（需先关掉浏览器）
#     ./一键配置.command --browser=edge # 指定浏览器
#     ./一键配置.command --help         # 查看全部参数
#
# 关于文件放哪：本脚本可以放在项目根目录，「素材」放同级的「配置文件夹」里；
# 也可以把脚本和素材都放在同一个目录。脚本会自动两边都找一遍：
#   素材 = tampermonkey_stable.crx + xxt-xiaoxin_demo.js
#   生成物（tampermonkey_ext / .browser-profile 等）会和素材放在一起，
#   这样根目录不会多出乱七八糟的文件夹。
#
# 默认使用「专用配置」：浏览器数据存在 .browser-profile 里，
# 不碰你平时的浏览器配置，也不会和已经开着的浏览器冲突。
#
# 注意：素材文件夹不要移动或改名。油猴的扩展 ID 是按扩展目录绝对路径算出来的，
# 换路径会被浏览器当成另一个扩展，之前的油猴设置和已装脚本会"消失"（其实还
# 在老路径对应的配置里）。真要移动，请连素材一起移动，并重新运行本脚本。
#
set -euo pipefail

# ---------------------------- 基础路径 ----------------------------
SELF="${BASH_SOURCE[0]}"
SCRIPT_DIR="$(cd "$(dirname "$SELF")" && pwd)"

# 素材（CRX + 用户脚本）可能和脚本同目录，也可能在同级的「配置文件夹」里。
# 生成物一律跟着素材走，放脚本所在目录会污染根目录。
ASSET_DIR=""
for d in "$SCRIPT_DIR" "$SCRIPT_DIR/配置文件夹"; do
  if [ -f "$d/tampermonkey_stable.crx" ]; then ASSET_DIR="$d"; break; fi
done
[ -n "$ASSET_DIR" ] || ASSET_DIR="$SCRIPT_DIR"   # 都没找到时先按脚本目录走，后面统一报错

CRX_FILE="$ASSET_DIR/tampermonkey_stable.crx"
EXT_DIR="$ASSET_DIR/tampermonkey_ext"
STAMP_FILE="$ASSET_DIR/.crx.stamp"
SERVER_PID_FILE="$ASSET_DIR/.server.pid"
DEFAULT_PROFILE_DIR="$ASSET_DIR/.browser-profile"
USER_PROFILE_DIR=""          # 非空表示用 --main-profile

PORT=""
DRY_RUN=0
KEEP_SERVER=0
FORCE_EXTRACT=0
BROWSER_PICK=""

# ---------------------------- 输出样式 ----------------------------
if [ -t 1 ]; then
  C_OK=$'\033[32m'; C_WARN=$'\033[33m'; C_ERR=$'\033[31m'
  C_INFO=$'\033[36m'; C_DIM=$'\033[2m'; C_END=$'\033[0m'
else
  C_OK=""; C_WARN=""; C_ERR=""; C_INFO=""; C_DIM=""; C_END=""
fi
say()  { printf '%s\n' "$*"; }
ok()   { printf '%s✔%s %s\n' "$C_OK" "$C_END" "$*"; }
warn() { printf '%s!%s %s\n' "$C_WARN" "$C_END" "$*"; }
err()  { printf '%s✘%s %s\n' "$C_ERR" "$C_END" "$*"; }
info() { printf '%s·%s %s\n' "$C_INFO" "$C_END" "$*"; }
dim()  { printf '%s%s%s\n' "$C_DIM" "$*" "$C_END"; }
step() { printf '\n%s==> %s%s\n' "$C_INFO" "$*" "$C_END"; }

# ---------------------------- 参数解析 ----------------------------
usage() {
  # 只打印文件开头的注释块（遇到第一行非注释就停）
  awk 'NR > 2 { if ($0 !~ /^#/) exit; sub(/^# ?/, ""); print }' "$SELF"
  cat <<'EOF'

可用参数：
  --dry-run           只做环境检查和解包，不启动浏览器
  --main-profile      装进你平时用的浏览器配置（运行前必须先完全退出浏览器）
  --browser=名字      指定浏览器：chrome|canary|edge|brave|chromium|vivaldi|arc
  --port=端口         指定本地安装页端口（默认自动挑一个空闲端口）
  --keep-server       安装页服务器常驻，直到你手动结束（默认 15 分钟后自停）
  --reinstall         强制重新解包 CRX
  -h, --help          显示本帮助
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run)      DRY_RUN=1 ;;
    --main-profile) USER_PROFILE_DIR="__MAIN__" ;;
    --browser=*)    BROWSER_PICK="${1#*=}" ;;
    --port=*)       PORT="${1#*=}" ;;
    --keep-server)  KEEP_SERVER=1 ;;
    --reinstall)    FORCE_EXTRACT=1 ;;
    -h|--help)      usage; exit 0 ;;
    *) err "未知参数：$1"; echo; usage; exit 2 ;;
  esac
  shift
done

# ---------------------------- 清理逻辑 ----------------------------
SERVER_PID=""
# 只接管 Ctrl+C / 被结束的情况。正常退出时不关服务器：浏览器可能还在加载安装页，
# 服务器留着，由 15 分钟的看门狗收工。
cleanup() {
  if [ -n "$SERVER_PID" ] && kill -0 "$SERVER_PID" 2>/dev/null; then
    kill "$SERVER_PID" 2>/dev/null || true
    dim "已关闭本地安装页服务器"
  fi
  rm -f "$SERVER_PID_FILE"
}
trap cleanup INT TERM HUP

# ---------------------------- 环境检查 ----------------------------
step "1/6 检查文件"

if [ ! -f "$CRX_FILE" ]; then
  err "找不到油猴扩展文件：$CRX_FILE"
  dim "  请确认 tampermonkey_stable.crx 和本脚本放在同一个文件夹里，"
  dim "  或放在脚本同级的「配置文件夹」里。"
  exit 1
fi
ok "油猴扩展：$(basename "$CRX_FILE")（$(du -h "$CRX_FILE" | cut -f1)）"
dim "  素材目录：$ASSET_DIR"

# 自动找用户脚本：优先 *.user.js，其次找内容里带 ==UserScript== 的 .js
# 只认真实文件，跳过本脚本自己生成的软链，避免套娃成 xx.user.user.js
find "$ASSET_DIR" "$SCRIPT_DIR" -maxdepth 1 -type l -name '*.user.user.js' -delete 2>/dev/null || true
USCRIPT=""
for search_dir in "$ASSET_DIR" "$SCRIPT_DIR"; do
  [ -d "$search_dir" ] || continue
  for f in "$search_dir"/*.user.js; do
    if [ -f "$f" ] && [ ! -L "$f" ]; then USCRIPT="$f"; break; fi
  done
  [ -n "$USCRIPT" ] && break
done
if [ -z "$USCRIPT" ]; then
  for search_dir in "$ASSET_DIR" "$SCRIPT_DIR"; do
    [ -d "$search_dir" ] || continue
    while IFS= read -r f; do
      if head -c 400 "$f" 2>/dev/null | grep -q "==UserScript=="; then
        USCRIPT="$f"; break
      fi
    done < <(find "$search_dir" -maxdepth 1 -name '*.js' -type f -print0 \
               | xargs -0 ls -t 2>/dev/null)
    [ -n "$USCRIPT" ] && break
  done
fi
if [ -z "$USCRIPT" ]; then
  err "没找到用户脚本（需要 .user.js，或开头带 ==UserScript== 的 .js）"
  dim "  请把 xxt-xiaoxin_demo.js 放到 $ASSET_DIR 里。"
  exit 1
fi
ok "用户脚本：$(basename "$USCRIPT")"

# 安装页需要一个 .user.js 结尾的地址，油猴才会自动认出来
SERVE_NAME="$(basename "${USCRIPT%.js}").user.js"
SERVE_LINK="$ASSET_DIR/$SERVE_NAME"
if [ "$(basename "$USCRIPT")" != "$SERVE_NAME" ]; then
  ln -sfn "$(basename "$USCRIPT")" "$SERVE_LINK"
  dim "  已准备安装页地址用的软链：$SERVE_NAME"
fi

# ---------------------------- 解包 CRX ----------------------------
step "2/6 解包油猴扩展"

crx_stamp="$(stat -f '%z-%m' "$CRX_FILE" 2>/dev/null || echo unknown)"
need_extract=1
if [ "$FORCE_EXTRACT" -eq 0 ] && [ -f "$EXT_DIR/manifest.json" ] \
   && [ -f "$STAMP_FILE" ] && [ "$(cat "$STAMP_FILE" 2>/dev/null)" = "$crx_stamp" ]; then
  need_extract=0
fi

if [ "$need_extract" -eq 0 ]; then
  ok "已解包且未变化，跳过（要强行重做加 --reinstall）"
else
  rm -rf "$EXT_DIR"
  mkdir -p "$EXT_DIR"
  extracted=0

  if command -v python3 >/dev/null 2>&1; then
    if python3 - "$CRX_FILE" "$EXT_DIR" <<'PY'
import io, os, struct, sys, zipfile

src, dst = sys.argv[1], sys.argv[2]
data = open(src, "rb").read()
if data[:4] != b"Cr24":
    sys.exit("不是 CRX 文件：文件头不是 Cr24")
version = struct.unpack("<I", data[4:8])[0]
if version == 3:
    offset = 12 + struct.unpack("<I", data[8:12])[0]
elif version == 2:
    pubkey_len, sig_len = struct.unpack("<I", data[8:12])[0], struct.unpack("<I", data[12:16])[0]
    offset = 16 + pubkey_len + sig_len
else:
    sys.exit("不认识的 CRX 版本：%d" % version)

zf = zipfile.ZipFile(io.BytesIO(data[offset:]))
dst_abs = os.path.abspath(dst)
for name in zf.namelist():
    target = os.path.abspath(os.path.join(dst_abs, name))
    if not target.startswith(dst_abs + os.sep) and target != dst_abs:
        sys.exit("压缩包里有可疑路径，已中止：%s" % name)
zf.extractall(dst_abs)
PY
    then
      extracted=1
    else
      warn "python3 解包失败，改用备用方式"
      rm -rf "$EXT_DIR"; mkdir -p "$EXT_DIR"
    fi
  fi

  if [ "$extracted" -eq 0 ]; then
    if command -v unzip >/dev/null 2>&1; then
      tmp_zip="$(mktemp -t tampermonkey).zip"
      offset="$(LC_ALL=C grep -abo $'PK\x03\x04' "$CRX_FILE" | head -1 | cut -d: -f1)"
      if [ -z "$offset" ]; then
        err "在 CRX 里找不到 zip 数据，文件可能损坏"
        rm -f "$tmp_zip"; exit 1
      fi
      tail -c "+$((offset + 1))" "$CRX_FILE" > "$tmp_zip"
      unzip -q -o "$tmp_zip" -d "$EXT_DIR"
      rm -f "$tmp_zip"
    else
      err "系统里没有 python3 也没有 unzip，无法解包"
      dim "  先在终端执行 xcode-select --install 装命令行工具，再重跑本脚本。"
      exit 1
    fi
  fi

  if [ ! -f "$EXT_DIR/manifest.json" ]; then
    err "解包结果不对：没有 manifest.json"
    exit 1
  fi

  # CRX 里自带的 _metadata 会让 Chrome 拒绝加载未打包扩展，必须删掉
  rm -rf "$EXT_DIR/_metadata"
  # 除 _locales / _platform_specific 外，其它下划线开头的条目 Chrome 也不接受
  while IFS= read -r odd; do
    [ -z "$odd" ] && continue
    warn "清掉 Chrome 不接受的条目：$(basename "$odd")"
    rm -rf "$odd"
  done < <(find "$EXT_DIR" -maxdepth 1 -name '_*' ! -name '_locales' ! -name '_platform_specific')

  printf '%s' "$crx_stamp" > "$STAMP_FILE"
  ok "已解包到 $(basename "$EXT_DIR")/"
fi

manifest_version="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["version"])' "$EXT_DIR/manifest.json" 2>/dev/null \
  || sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$EXT_DIR/manifest.json" | head -1)"
ok "油猴版本：${manifest_version:-未知}"

# ---------------------------- 扩展 ID ----------------------------
# 未打包扩展的 ID = 扩展目录绝对路径的 sha256 前 16 字节，十六进制映射到 a-p
EXT_ID="$(printf '%s' "$EXT_DIR" | shasum -a 256 | cut -c1-32 | tr '0123456789abcdef' 'abcdefghijklmnop')"
dim "  扩展 ID（按路径计算）：$EXT_ID"

# ---------------------------- 找浏览器 ----------------------------
step "3/6 查找浏览器"

find_browser() {
  # 输出：显示名<TAB>可执行文件路径
  local candidates=(
    "chrome|Google Chrome|/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    "canary|Google Chrome Canary|/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary"
    "edge|Microsoft Edge|/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
    "brave|Brave|/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"
    "chromium|Chromium|/Applications/Chromium.app/Contents/MacOS/Chromium"
    "vivaldi|Vivaldi|/Applications/Vivaldi.app/Contents/MacOS/Vivaldi"
    "arc|Arc|/Applications/Arc.app/Contents/MacOS/Arc"
  )
  local entry key name path
  for entry in "${candidates[@]}"; do
    key="${entry%%|*}"; entry="${entry#*|}"
    name="${entry%%|*}";  path="${entry#*|}"
    if [ -n "$BROWSER_PICK" ] && [ "$BROWSER_PICK" != "$key" ]; then continue; fi
    if [ -x "$path" ]; then printf '%s\t%s\n' "$name" "$path"; return 0; fi
    path="${path/\/Applications\//$HOME\/Applications\/}"
    if [ -x "$path" ]; then printf '%s\t%s\n' "$name" "$path"; return 0; fi
  done
  return 1
}

BROWSER_INFO="$(find_browser || true)"
if [ -n "$BROWSER_PICK" ] && [ -z "$BROWSER_INFO" ]; then
  err "没找到浏览器：$BROWSER_PICK"
  dim "  可用：chrome / canary / edge / brave / chromium / vivaldi / arc"
  exit 1
fi

if [ -z "$BROWSER_INFO" ]; then
  warn "没找到 Chromium 内核的浏览器（Chrome / Edge / Brave / Chromium / Vivaldi / Arc）"
  say
  if [ -d "/Applications/Firefox.app" ]; then
    dim "  检测到你装了 Firefox。CRX 扩展只能装进 Chromium 内核的浏览器，"
    dim "  Firefox 需要在附加组件商店装油猴（已帮你打开对应页面）。"
    if [ "$DRY_RUN" -eq 0 ]; then
      open "https://addons.mozilla.org/zh-CN/firefox/addon/tampermonkey/" 2>/dev/null || true
    fi
    say
  fi
  dim "  你也可以手动来：打开浏览器 → 扩展页 → 装好油猴 → 把 xxt 脚本粘进油猴。"
  exit 1
fi

BROWSER_NAME="${BROWSER_INFO%%$'\t'*}"
BROWSER_BIN="${BROWSER_INFO#*$'\t'}"
ok "使用浏览器：$BROWSER_NAME"
dim "  $BROWSER_BIN"

# ---------------------------- 准备配置目录 ----------------------------
step "4/6 准备浏览器配置"

if [ "$USER_PROFILE_DIR" = "__MAIN__" ]; then
  PROFILE_DIR="$HOME/Library/Application Support/Google/Chrome"
  warn "你选择了装进平时的浏览器配置"
  dim "  浏览器必须是完全退出的状态，否则新参数会被忽略、扩展装不上。"
  if pgrep -f "$BROWSER_BIN" >/dev/null 2>&1; then
    err "$BROWSER_NAME 正在运行，请先完全退出（⌘Q）再重跑本脚本"
    exit 1
  fi
  dim "  另外：这种方式加载的扩展只在本次启动有效，下次手动打开浏览器时油猴可能不在。"
  dim "  想长期使用，建议用默认的专用配置（不加 --main-profile）。"
else
  PROFILE_DIR="$DEFAULT_PROFILE_DIR"
  if [ "$DRY_RUN" -eq 0 ]; then
    mkdir -p "$PROFILE_DIR"
    # 首次创建配置时顺手把「开发者模式」打开，避免油猴的 MV3 用户脚本权限被拦
    if [ ! -f "$PROFILE_DIR/Default/Preferences" ]; then
      mkdir -p "$PROFILE_DIR/Default"
      printf '%s' '{"extensions":{"ui":{"developer_mode":true}}}' > "$PROFILE_DIR/Default/Preferences"
      dim "  已初始化专用配置（并默认打开开发者模式）"
    fi
  fi
  ok "专用配置目录：$(basename "$PROFILE_DIR")/"
fi

# 跳过首次运行的向导与默认浏览器检查
LAUNCH_FLAGS=(
  --user-data-dir="$PROFILE_DIR"
  --load-extension="$EXT_DIR"
  --no-first-run
  --no-default-browser-check
)

# ---------------------------- 启动安装页服务器 ----------------------------
step "5/6 启动本地安装页"

if [ -z "$PORT" ]; then
  PORT=8731
  while nc -z 127.0.0.1 "$PORT" 2>/dev/null; do PORT=$((PORT + 1)); done
fi

INSTALL_URL="http://127.0.0.1:$PORT/$SERVE_NAME"

if [ "$DRY_RUN" -eq 1 ]; then
  dim "  [dry-run] 安装页地址会是：$INSTALL_URL"
  dim "  [dry-run] 启动命令会是："
  dim "            \"$BROWSER_BIN\" ${LAUNCH_FLAGS[*]} \"$INSTALL_URL\""
else
  if ! command -v python3 >/dev/null 2>&1; then
    warn "没有 python3，起不了本地安装页"
    dim "  没关系：浏览器照样会带油猴启动，你手动把脚本粘进油猴即可（见下面的说明）。"
    INSTALL_URL=""
  else
    ( cd "$ASSET_DIR" && exec python3 -m http.server "$PORT" --bind 127.0.0.1 ) >/dev/null 2>&1 &
    SERVER_PID=$!
    printf '%s' "$SERVER_PID" > "$SERVER_PID_FILE"
    sleep 1
    if kill -0 "$SERVER_PID" 2>/dev/null; then
      ok "安装页已就绪：$INSTALL_URL"
      if [ "$KEEP_SERVER" -eq 0 ]; then
        # 15 分钟后自动收工，避免留下后台进程
        ( sleep 900; kill "$SERVER_PID" 2>/dev/null; rm -f "$SERVER_PID_FILE" ) >/dev/null 2>&1 &
      fi
    else
      warn "安装页没起来（端口 $PORT 可能被占用），改用 --port=其他端口 再试"
      INSTALL_URL=""
    fi
  fi
fi

# ---------------------------- 启动浏览器 ----------------------------
step "6/6 启动浏览器"

if [ "$DRY_RUN" -eq 1 ]; then
  dim "  [dry-run] 到此为止，没有真的启动浏览器"
  exit 0
fi

if [ -n "$INSTALL_URL" ]; then
  "$BROWSER_BIN" "${LAUNCH_FLAGS[@]}" "$INSTALL_URL" >/dev/null 2>&1 &
  ok "已启动 $BROWSER_NAME，并打开了脚本安装页"
else
  "$BROWSER_BIN" "${LAUNCH_FLAGS[@]}" >/dev/null 2>&1 &
  ok "已启动 $BROWSER_NAME"
fi

# 没能自动打开安装页时，才把扩展管理页开出来，方便手动检查
if [ -z "$INSTALL_URL" ]; then
  open -a "$BROWSER_NAME" "chrome://extensions/" >/dev/null 2>&1 || true
fi

cat <<EOF

$(printf '%s' "$C_INFO")================ 接下来只需要点几下 ================$(printf '%s' "$C_END")

1) 窗口里如果出现「安装此脚本」页面，点【安装】
   没看到安装页的话，用这个地址手动打开：
   $INSTALL_URL

2) 装完检查一下油猴是否正常工作：
   地址栏输入 chrome://extensions 回车，找到 Tampermonkey
   - 如果它显示「已停用」，把它打开
   - 如果提示需要打开「开发者模式」或「允许用户脚本」，按提示打开即可
     （本次启动已经默认带上开发者模式，一般不会遇到）

3) 打开学习通课程页面，右下角出现面板后，
   到「API配置」标签页填你的 DeepSeek API Key，点「保存并测试」变绿即可。

$(printf '%s' "$C_DIM")说明：$(printf '%s' "$C_END")
$(printf '%s' "$C_DIM")  · 这个浏览器用的是专用配置，和你平时的浏览器互不影响。$(printf '%s' "$C_END")
$(printf '%s' "$C_DIM")  · 以后再用：直接双击本脚本，它会用同一个配置启动，油猴和脚本都还在。$(printf '%s' "$C_END")
$(printf '%s' "$C_DIM")  · 不要移动或改名素材文件夹（配置文件夹），否则扩展会被当成新的，油猴里的脚本会看不到。$(printf '%s' "$C_END")
$(printf '%s' "$C_DIM")  · 想装进平时的浏览器：先退出浏览器，再跑 ./一键配置.command --main-profile$(printf '%s' "$C_END")

EOF

if [ -n "$SERVER_PID" ]; then
  dim "本地安装页服务器会在 15 分钟后自动关闭。"
  dim "想现在关掉：kill \$(cat \"$SERVER_PID_FILE\")"
fi
