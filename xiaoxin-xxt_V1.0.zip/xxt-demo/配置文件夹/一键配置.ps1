<#
  学习通助手 · 懒人一键配置（Windows / PowerShell 实现）

  这个文件是 一键配置.bat 里那段 BASE64 的来源，正常用不到它，双击
  一键配置.bat 就行。想读懂或改实现时看这里。

  当前布局：一键配置.command / 一键配置.bat 放在项目根目录（双击用），
  本文件（实现源码）和素材一起放在同级的「配置文件夹」里。
  脚本对位置不敏感，先找自己所在目录，再找同级的「配置文件夹」：
      素材 = tampermonkey_stable.crx + xxt-xiaoxin_demo.js
      生成物（tampermonkey_ext / .browser-profile 等）跟着素材放，
      这样项目根目录不会多出乱七八糟的文件夹。

  注意：本文件是 UTF-8 无 BOM。想直接运行它，请这样（用 -File 会因为
  编码判断问题让中文乱码）：
      powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $c=[IO.File]::ReadAllText('.\一键配置.ps1', [Text.Encoding]::UTF8); & ([ScriptBlock]::Create($c)) }"

  由 .bat 调用时，参数通过环境变量传入（这样绕开中文和引号的转义问题）：
      XXT_ROOT         配置文件夹路径，必填，.bat 里用 %~dp0 传进来
      XXT_DRYRUN       1 = 只检查、不启动浏览器
      XXT_MAINPROFILE  1 = 装进你平时的浏览器配置
      XXT_BROWSER      指定浏览器，如 chrome / edge / brave / chromium / vivaldi
      XXT_REINSTALL    1 = 强制重新解包 CRX
      XXT_PORT         指定端口
      XXT_MODE         serve = 只启动本地安装页服务器（脚本自己用它开后台进程）

  做四件事：解包油猴 CRX → 删掉 Chrome 不允许的 _metadata → 用一个本地
  HTTP 服务把脚本喂给油猴的安装页 → 带扩展参数启动浏览器。
#>

$ErrorActionPreference = 'Stop'

try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }

# ---------------------------- 输出样式 ----------------------------
function Say  ([string]$m) { Write-Host $m }
function Ok   ([string]$m) { Write-Host "√ " -ForegroundColor Green -NoNewline; Write-Host $m }
function Warn ([string]$m) { Write-Host "! " -ForegroundColor Yellow -NoNewline; Write-Host $m }
function Err  ([string]$m) { Write-Host "× " -ForegroundColor Red -NoNewline; Write-Host $m }
function Info ([string]$m) { Write-Host "· " -ForegroundColor Cyan -NoNewline; Write-Host $m }
function Dim  ([string]$m) { Write-Host $m -ForegroundColor DarkGray }
function Step ([string]$m) { Write-Host ''; Write-Host "==> $m" -ForegroundColor Cyan }

# ---------------------------- 本地安装页服务器 ----------------------------
# 用最原始的 TCP 实现一个只读的静态文件服务：不依赖 Python/Node，
# 只绑 127.0.0.1，不会触发 Windows 防火墙弹窗。
function Start-InstallServer {
    $root = $env:XXT_SERVE_ROOT
    $port = 0
    [void][int]::TryParse($env:XXT_SERVE_PORT, [ref]$port)
    $entryName = $env:XXT_SERVE_FILE
    if ([string]::IsNullOrWhiteSpace($root) -or $port -le 0) { return }

    $rootFull = [IO.Path]::GetFullPath($root).TrimEnd('\')
    $listener = New-Object Net.Sockets.TcpListener -ArgumentList ([Net.IPAddress]::Loopback), $port
    $listener.Start()

    $mime = @{
        '.js'   = 'application/javascript; charset=utf-8'
        '.html' = 'text/html; charset=utf-8'
        '.json' = 'application/json; charset=utf-8'
        '.css'  = 'text/css; charset=utf-8'
        '.crx'  = 'application/x-chrome-extension'
    }
    $deadline = (Get-Date).AddMinutes(15)

    while ((Get-Date) -lt $deadline) {
        if (-not $listener.Pending()) { Start-Sleep -Milliseconds 150; continue }
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $stream.ReadTimeout = 3000
            $buf = New-Object byte[] 8192
            $read = 0
            try { $read = $stream.Read($buf, 0, $buf.Length) } catch { $read = 0 }
            $req = [Text.Encoding]::ASCII.GetString($buf, 0, $read)

            $target = '/'
            if ($req -match '(?m)^GET\s+(\S+)') { $target = $Matches[1] }
            $target = $target.Split('?')[0]
            $rel = [Uri]::UnescapeDataString($target).TrimStart('/')
            if ([string]::IsNullOrWhiteSpace($rel)) { $rel = 'index.html' }

            $body = $null
            $ctype = 'application/octet-stream'

            if ($rel -eq 'index.html' -and -not (Test-Path -LiteralPath (Join-Path $rootFull 'index.html'))) {
                # 现生成一个说明页：直接导航 .user.js 没触发安装时，点这里的链接
                $html = '<!doctype html><meta charset="utf-8"><title>学习通助手 · 安装</title>' +
                        '<body style="font:15px/1.8 -apple-system,Segoe UI,Microsoft YaHei,sans-serif;padding:28px;max-width:640px">' +
                        '<h2>学习通助手 · 本地安装页</h2>' +
                        '<p>点下面这个链接，油猴会弹出安装页，点【安装】即可：</p>' +
                        '<p><a style="font-size:17px" href="/' + $entryName + '">安装 ' + $entryName + '</a></p>' +
                        '<p style="color:#666;font-size:13px">如果点开是纯文本、没有安装按钮：先确认已装好并启用了 Tampermonkey，' +
                        '再到 chrome://extensions 里给它打开「允许用户脚本」。</p></body>'
                $body = [Text.Encoding]::UTF8.GetBytes($html)
                $ctype = 'text/html; charset=utf-8'
            }
            else {
                $full = [IO.Path]::GetFullPath((Join-Path $rootFull $rel))
                if ((-not (Test-Path -LiteralPath $full -PathType Leaf)) -and $rel.EndsWith('.user.js')) {
                    # 磁盘上没有 xx.user.js 时，退一步读同名的 .js（虚拟别名，不动磁盘文件）
                    $alt = $rel.Substring(0, $rel.Length - 8) + '.js'
                    $full = [IO.Path]::GetFullPath((Join-Path $rootFull $alt))
                }
                if ($full.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $full -PathType Leaf)) {
                    $body = [IO.File]::ReadAllBytes($full)
                    $ext = [IO.Path]::GetExtension($full).ToLower()
                    if ($mime.ContainsKey($ext)) { $ctype = $mime[$ext] }
                }
            }

            if ($null -ne $body) {
                $head = "HTTP/1.1 200 OK`r`nContent-Type: $ctype`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
            }
            else {
                $body = [Text.Encoding]::UTF8.GetBytes('404 not found')
                $head = "HTTP/1.1 404 Not Found`r`nContent-Type: text/plain; charset=utf-8`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
            }
            $hb = [Text.Encoding]::ASCII.GetBytes($head)
            $stream.Write($hb, 0, $hb.Length)
            $stream.Write($body, 0, $body.Length)
            $stream.Flush()
        }
        catch { }
        finally { try { $client.Close() } catch { } }
    }
    try { $listener.Stop() } catch { }
}

# ---------------------------- 解包 CRX ----------------------------
function Expand-Crx {
    param([string]$CrxPath, [string]$DestDir)

    $bytes = [IO.File]::ReadAllBytes($CrxPath)
    if ($bytes.Length -lt 16 -or [Text.Encoding]::ASCII.GetString($bytes, 0, 4) -ne 'Cr24') {
        throw '不是有效的 CRX 文件（文件头不是 Cr24）'
    }
    $version = [BitConverter]::ToUInt32($bytes, 4)
    if ($version -eq 3) {
        $offset = 12 + [BitConverter]::ToUInt32($bytes, 8)
    }
    elseif ($version -eq 2) {
        $offset = 16 + [BitConverter]::ToUInt32($bytes, 8) + [BitConverter]::ToUInt32($bytes, 12)
    }
    else {
        throw "不认识的 CRX 版本：$version"
    }

    $tmpZip = Join-Path $env:TEMP ('xxt_crx_' + [Guid]::NewGuid().ToString('N') + '.zip')
    $fs = [IO.File]::Create($tmpZip)
    try { $fs.Write($bytes, $offset, $bytes.Length - $offset) } finally { $fs.Close() }

    if (Test-Path -LiteralPath $DestDir) { Remove-Item -LiteralPath $DestDir -Recurse -Force }
    New-Item -ItemType Directory -Path $DestDir -Force | Out-Null

    $done = $false
    try {
        Expand-Archive -LiteralPath $tmpZip -DestinationPath $DestDir -Force
        $done = $true
    }
    catch { $done = $false }
    if (-not $done) {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        if (Test-Path -LiteralPath $DestDir) { Remove-Item -LiteralPath $DestDir -Recurse -Force }
        New-Item -ItemType Directory -Path $DestDir -Force | Out-Null
        [IO.Compression.ZipFile]::ExtractToDirectory($tmpZip, $DestDir)
    }
    Remove-Item -LiteralPath $tmpZip -Force -ErrorAction SilentlyContinue
}

# ---------------------------- 扩展 ID ----------------------------
# 未打包扩展的 ID = 扩展目录绝对路径（Windows 上先转大写）的 sha256 前 16 字节，
# 十六进制逐位映射到 a-p。仅用于打印提示，不参与功能。
function Get-UnpackedExtensionId {
    param([string]$ExtDir)
    $sha = [Security.Cryptography.SHA256]::Create()
    $hash = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($ExtDir.ToUpperInvariant()))
    $hex = ''
    for ($i = 0; $i -lt 16; $i++) { $hex += $hash[$i].ToString('x2') }
    $id = ''
    foreach ($ch in $hex.ToCharArray()) { $id += [char]([Convert]::ToInt32([string]$ch, 16) + [int][char]'a') }
    return $id
}

# ---------------------------- 找浏览器 ----------------------------
function Find-Browser {
    param([string]$Pick)

    $candidates = @(
        @{ Key = 'chrome';   Name = 'Google Chrome';   Rel = 'Google\Chrome\Application\chrome.exe' },
        @{ Key = 'canary';   Name = 'Chrome Canary';   Rel = 'Google\Chrome SxS\Application\chrome.exe' },
        @{ Key = 'edge';     Name = 'Microsoft Edge';  Rel = 'Microsoft\Edge\Application\msedge.exe' },
        @{ Key = 'brave';    Name = 'Brave';           Rel = 'BraveSoftware\Brave-Browser\Application\brave.exe' },
        @{ Key = 'chromium'; Name = 'Chromium';        Rel = 'Chromium\Application\chrome.exe' },
        @{ Key = 'vivaldi';  Name = 'Vivaldi';         Rel = 'Vivaldi\Application\vivaldi.exe' }
    )
    $bases = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)

    foreach ($c in $candidates) {
        if (-not [string]::IsNullOrWhiteSpace($Pick) -and $Pick -ne $c.Key) { continue }
        foreach ($b in $bases) {
            if ([string]::IsNullOrWhiteSpace($b)) { continue }
            $p = Join-Path $b $c.Rel
            if (Test-Path -LiteralPath $p -PathType Leaf) {
                return @{ Name = $c.Name; Path = $p; ProcessName = ([IO.Path]::GetFileNameWithoutExtension($p)) }
            }
        }
        # 兜底：从注册表的 App Paths 里找（装在非标准目录时有用）
        $exe = [IO.Path]::GetFileName($c.Rel)
        $regPaths = @(
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe",
            "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe"
        )
        foreach ($rp in $regPaths) {
            try {
                $val = (Get-ItemProperty -Path $rp -ErrorAction Stop).'(default)'
                if (-not [string]::IsNullOrWhiteSpace($val) -and (Test-Path -LiteralPath $val -PathType Leaf)) {
                    return @{ Name = $c.Name; Path = $val; ProcessName = ([IO.Path]::GetFileNameWithoutExtension($val)) }
                }
            }
            catch { }
        }
    }
    return $null
}

# ---------------------------- 主流程 ----------------------------
function Invoke-Setup {
    $scriptDir = $env:XXT_ROOT
    if ([string]::IsNullOrWhiteSpace($scriptDir)) { $scriptDir = (Get-Location).Path }
    $scriptDir = $scriptDir.TrimEnd('\', '/')
    if (-not (Test-Path -LiteralPath $scriptDir -PathType Container)) { Err "找不到文件夹：$scriptDir"; exit 1 }

    # 素材（CRX + 用户脚本）可能和 .bat 同目录，也可能在同级的「配置文件夹」里。
    # 生成物一律跟着素材走，避免污染项目根目录。
    $assetDir = $null
    foreach ($d in @($scriptDir, (Join-Path $scriptDir '配置文件夹'))) {
        if (Test-Path -LiteralPath (Join-Path $d 'tampermonkey_stable.crx') -PathType Leaf) { $assetDir = $d; break }
    }
    if ($null -eq $assetDir) { $assetDir = $scriptDir }

    $crxFile    = Join-Path $assetDir 'tampermonkey_stable.crx'
    $extDir     = Join-Path $assetDir 'tampermonkey_ext'
    $stampFile  = Join-Path $assetDir '.crx.stamp'
    $profileDir = Join-Path $assetDir '.browser-profile'

    $dryRun      = ($env:XXT_DRYRUN -eq '1')
    $mainProfile = ($env:XXT_MAINPROFILE -eq '1')
    $forceExtract = ($env:XXT_REINSTALL -eq '1')
    $browserPick = $env:XXT_BROWSER
    if (-not [string]::IsNullOrWhiteSpace($browserPick)) {
        $browserPick = ($browserPick -replace '.*--browser=', '')
    }
    $portWanted = 0
    if (-not [string]::IsNullOrWhiteSpace($env:XXT_PORT)) {
        [void][int]::TryParse(($env:XXT_PORT -replace '.*--port=', ''), [ref]$portWanted)
    }

    # ---------- 1/6 检查文件 ----------
    Step '1/6 检查文件'
    if (-not (Test-Path -LiteralPath $crxFile -PathType Leaf)) {
        Err "找不到油猴扩展文件：$crxFile"
        Dim '  请确认 tampermonkey_stable.crx 和本脚本放在同一个文件夹里，'
        Dim '  或放在脚本同级的「配置文件夹」里。'
        exit 1
    }
    Ok ("油猴扩展：tampermonkey_stable.crx（{0:N1} MB）" -f ((Get-Item -LiteralPath $crxFile).Length / 1MB))
    Dim "  素材目录：$assetDir"

    $searchDirs = @($assetDir)
    if ($scriptDir -ne $assetDir) { $searchDirs += $scriptDir }

    $uscript = $null
    foreach ($d in $searchDirs) {
        $found = Get-ChildItem -LiteralPath $d -Filter '*.user.js' -File -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($null -ne $found) { $uscript = $found.FullName; break }
    }
    if ($null -eq $uscript) {
        foreach ($d in $searchDirs) {
            $all = Get-ChildItem -LiteralPath $d -Filter '*.js' -File -ErrorAction SilentlyContinue |
                   Sort-Object LastWriteTime -Descending
            $hit = $null
            foreach ($f in $all) {
                $head = ''
                try { $head = [string](Get-Content -LiteralPath $f.FullName -TotalCount 5 -Encoding UTF8 -ErrorAction Stop) }
                catch { $head = '' }
                if ($head.Contains('==UserScript==')) { $hit = $f.FullName; break }
            }
            if ($null -ne $hit) { $uscript = $hit; break }
        }
    }
    if ($null -eq $uscript) {
        Err '没找到用户脚本（需要 .user.js，或开头带 ==UserScript== 的 .js）'
        Dim "  请把 xxt-xiaoxin_demo.js 放到 $assetDir 里。"
        exit 1
    }
    Ok ("用户脚本：{0}" -f (Split-Path -Leaf $uscript))
    $serveName = [IO.Path]::GetFileNameWithoutExtension($uscript) + '.user.js'

    # ---------- 2/6 解包 ----------
    Step '2/6 解包油猴扩展'
    $crxStamp = '{0}-{1}' -f ((Get-Item -LiteralPath $crxFile).Length), ((Get-Item -LiteralPath $crxFile).LastWriteTimeUtc.Ticks)
    $needExtract = $true
    if ((-not $forceExtract) -and (Test-Path -LiteralPath (Join-Path $extDir 'manifest.json'))) {
        if ((Test-Path -LiteralPath $stampFile) -and ((Get-Content -LiteralPath $stampFile -Raw).Trim() -eq $crxStamp)) {
            $needExtract = $false
        }
    }

    if (-not $needExtract) {
        Ok '已解包且未变化，跳过（要强行重做加 --reinstall）'
    }
    else {
        try { Expand-Crx -CrxPath $crxFile -DestDir $extDir }
        catch { Err "解包失败：$($_.Exception.Message)"; exit 1 }

        # CRX 自带的 _metadata 会让 Chrome 拒绝加载未打包扩展，必须删掉
        Get-ChildItem -LiteralPath $extDir -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name.StartsWith('_') -and $_.Name -ne '_locales' -and $_.Name -ne '_platform_specific' } |
            ForEach-Object {
                Warn "清掉 Chrome 不接受的条目：$($_.Name)"
                Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
            }

        if (-not (Test-Path -LiteralPath (Join-Path $extDir 'manifest.json'))) {
            Err '解包结果不对：没有 manifest.json'
            exit 1
        }
        [IO.File]::WriteAllText($stampFile, $crxStamp)
        Ok '已解包到 tampermonkey_ext\'
    }

    $extVersion = '未知'
    try {
        $mj = Get-Content -LiteralPath (Join-Path $extDir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        $extVersion = $mj.version
    }
    catch { }
    Ok "油猴版本：$extVersion"
    Dim ("  扩展 ID（按路径计算）：{0}" -f (Get-UnpackedExtensionId -ExtDir $extDir))

    # ---------- 3/6 找浏览器 ----------
    Step '3/6 查找浏览器'
    $browser = Find-Browser -Pick $browserPick
    if ($null -eq $browser) {
        if (-not [string]::IsNullOrWhiteSpace($browserPick)) {
            Err "没找到浏览器：$browserPick"
            Dim '  可用：chrome / canary / edge / brave / chromium / vivaldi'
        }
        else {
            Warn '没找到 Chromium 内核的浏览器（Chrome / Edge / Brave / Chromium / Vivaldi）'
            Dim '  CRX 扩展只能装进 Chromium 内核的浏览器，Firefox 装不了。'
            Dim '  你可以手动来：装好浏览器和油猴，再把 xxt 脚本粘进油猴编辑器。'
        }
        exit 1
    }
    Ok "使用浏览器：$($browser.Name)"
    Dim "  $($browser.Path)"

    # ---------- 4/6 配置目录 ----------
    Step '4/6 准备浏览器配置'
    if ($mainProfile) {
        Warn '你选择了装进平时的浏览器配置'
        $running = Get-Process -Name $browser.ProcessName -ErrorAction SilentlyContinue
        if ($null -ne $running) {
            Err "$($browser.Name) 正在运行，请先完全退出再重跑本脚本"
            Dim '  不退出的话，新的启动参数会被忽略，扩展装不上。'
            exit 1
        }
        Dim '  这种方式加载的扩展只在本次启动有效，下次手动打开浏览器时油猴可能不在。'
        Dim '  想长期使用，建议用默认的专用配置（不加 --main-profile）。'
    }
    else {
        if (-not $dryRun) {
            if (-not (Test-Path -LiteralPath $profileDir)) { New-Item -ItemType Directory -Path $profileDir -Force | Out-Null }
            $prefFile = Join-Path $profileDir 'Default\Preferences'
            if (-not (Test-Path -LiteralPath $prefFile)) {
                New-Item -ItemType Directory -Path (Join-Path $profileDir 'Default') -Force | Out-Null
                [IO.File]::WriteAllText($prefFile, '{"extensions":{"ui":{"developer_mode":true}}}')
                Dim '  已初始化专用配置（并默认打开开发者模式）'
            }
        }
        Ok '专用配置目录：.browser-profile\'
    }

    # ---------- 5/6 本地安装页 ----------
    Step '5/6 启动本地安装页'
    $port = $portWanted
    if ($port -le 0) {
        $probe = New-Object Net.Sockets.TcpListener -ArgumentList ([Net.IPAddress]::Loopback), 0
        $probe.Start()
        $port = $probe.LocalEndpoint.Port
        $probe.Stop()
    }
    $installUrl = "http://127.0.0.1:$port/$serveName"

    if ($dryRun) {
        $profileShown = $profileDir
        if ($mainProfile) { $profileShown = '<你平时的浏览器配置>' }
        Dim "  [dry-run] 安装页地址会是：$installUrl"
        Dim '  [dry-run] 启动命令会是：'
        Dim "            `"$($browser.Path)`" --user-data-dir=`"$profileShown`" --load-extension=`"$extDir`" `"$installUrl`""
    }
    else {
        $serverCode = Get-InstallServerCode
        $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($serverCode))
        $env:XXT_SERVE_ROOT = $assetDir
        $env:XXT_SERVE_PORT = [string]$port
        $env:XXT_SERVE_FILE = $serveName
        try {
            Start-Process -FilePath 'powershell.exe' `
                          -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', $encoded) `
                          -WindowStyle Hidden | Out-Null
        }
        catch { Warn "本地安装页没起来：$($_.Exception.Message)" }

        # 等它真的能连上，免得浏览器开太快打不开页面
        $up = $false
        for ($i = 0; $i -lt 20; $i++) {
            try {
                $t = New-Object Net.Sockets.TcpClient
                $t.Connect('127.0.0.1', $port)
                $t.Close()
                $up = $true
                break
            }
            catch { Start-Sleep -Milliseconds 250 }
        }
        if ($up) { Ok "安装页已就绪：$installUrl" }
        else { Warn "安装页没起来（端口 $port 可能被占用），可以加 --port=其他端口 再试"; $installUrl = '' }
    }

    # ---------- 6/6 启动浏览器 ----------
    Step '6/6 启动浏览器'
    if ($dryRun) { Dim '  [dry-run] 到此为止，没有真的启动浏览器'; return }

    $userDataDir = $profileDir
    if ($mainProfile) { $userDataDir = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data' }

    $argLine = "--user-data-dir=`"$userDataDir`" --load-extension=`"$extDir`" --no-first-run --no-default-browser-check"
    if (-not [string]::IsNullOrWhiteSpace($installUrl)) { $argLine += " `"$installUrl`"" }
    try {
        Start-Process -FilePath $browser.Path -ArgumentList $argLine | Out-Null
    }
    catch { Err "启动失败：$($_.Exception.Message)"; exit 1 }
    Ok "已启动 $($browser.Name)"

    if ([string]::IsNullOrWhiteSpace($installUrl)) {
        # 没能自动开安装页，就把扩展管理页开出来，方便手动检查
        try { Start-Process -FilePath $browser.Path -ArgumentList 'chrome://extensions/' | Out-Null } catch { }
    }

    Say ''
    Say '================ 接下来只需要点几下 ================'
    Say ''
    Say '1) 窗口里如果出现「安装此脚本」页面，点【安装】'
    if (-not [string]::IsNullOrWhiteSpace($installUrl)) {
        Say "   没看到安装页的话，用这个地址手动打开："
        Say "   $installUrl"
    }
    Say ''
    Say '2) 装完检查一下油猴是否正常工作：'
    Say '   地址栏输入 chrome://extensions 回车，找到 Tampermonkey'
    Say '   - 显示「已停用」就把它打开'
    Say '   - 提示要打开「开发者模式」或「允许用户脚本」，按提示打开即可'
    Say ''
    Say '3) 打开学习通课程页面，右下角出现面板后，'
    Say '   到「API配置」标签页填你的 DeepSeek API Key，点「保存并测试」变绿即可。'
    Say ''
    Dim '说明：'
    Dim '  · 这个浏览器用的是专用配置，和你平时的浏览器互不影响。'
    Dim '  · 以后再用：直接双击本脚本，它会用同一个配置启动，油猴和脚本都还在。'
    Dim '  · 不要把素材文件夹（配置文件夹）改名或移动，否则扩展会被当成新的，油猴里的脚本会看不到。'
    Dim '  · 想装进平时的浏览器：先完全退出浏览器，再运行 一键配置.bat --main-profile'
    Say ''
}

# 把本进程里已经定义好的服务器函数原样抽出来，交给后台进程执行。
# 用函数定义而不是读文件，这样无论本脚本是 .ps1 还是 .bat 里的 EncodedCommand 都能用。
function Get-InstallServerCode {
    $def = (Get-Item function:Start-InstallServer).Definition
    return "function Start-InstallServer {`r`n" + $def + "`r`n}`r`nStart-InstallServer"
}

# ---------------------------- 入口 ----------------------------
if ($env:XXT_MODE -eq 'serve') {
    Start-InstallServer
}
else {
    Invoke-Setup
}
